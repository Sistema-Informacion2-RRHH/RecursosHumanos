-- Created at 28.4.2019 18:41 using David Grudl MySQL Dump Utility
-- Host: 127.0.0.1:8000
-- MySQL Server: 5.5.5-10.1.19-MariaDB
-- Database: test

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET AUTOCOMMIT=0;
-- --------------------------------------------------------

DROP TABLE IF EXISTS `prueba`;

CREATE TABLE `prueba` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `prueba` DISABLE KEYS;

INSERT INTO `prueba` (`id`, `nombre`) VALUES
(1,	'hola');
ALTER TABLE `prueba` ENABLE KEYS;



COMMIT;
-- THE END
